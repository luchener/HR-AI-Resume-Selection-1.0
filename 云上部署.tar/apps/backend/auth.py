"""
JWT 认证 + 用户管理。

设计要点：
- 无数据库依赖，用户信息存 JSON 文件（data/users/）。
- 注册：用户名 + 密码 → 创建 user 记录，返回 JWT。
- 登录：用户名 + 密码 → 校验，返回 JWT。
- 中间件：从 Authorization header 提取 Bearer token，校验签名和过期时间，
  注入 request.auth_user（包含 user_id / username）。
- /ping、/api/v1/auth/register、/api/v1/auth/login 免认证。
- 密码用 PBKDF2-SHA256 + 随机盐（标准库，零额外依赖）。
- JWT 用 PyJWT（HS256），密钥来自 .env 的 JWT_SECRET_KEY。
"""
import base64
import hashlib
import hmac
import json
import os
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

import jwt
from flask import g, jsonify, request

import config
from config import DATA_DIR


def _request_id(service: str = "auth") -> str:
    """与 app._request_id 格式一致：服务段:uuid。"""
    return f"{service}:{uuid.uuid4()}"

# ── JWT 配置 ────────────────────────────────────────────────────────────
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_SECONDS = 7 * 24 * 3600  # 7 天

# 免认证路径白名单（精确匹配 path，不含 query）
_PUBLIC_PATHS = {
    "/ping",
    "/api/v1/auth/register",
    "/api/v1/auth/login",
}


# ═══════════════════════════════════════════════════════════════════════
# 用户存储（JSON 文件，data/users/<user_id>.json）
# ═══════════════════════════════════════════════════════════════════════

USERS_DIR = os.path.join(DATA_DIR, "users")


def _write_json(path: str, data: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.{os.getpid()}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _read_json(path: str) -> Optional[dict]:
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ═══════════════════════════════════════════════════════════════════════
# 密码哈希（PBKDF2-SHA256，标准库实现，零额外依赖）
# ═══════════════════════════════════════════════════════════════════════

_PBKDF2_ITERATIONS = 200_000


def hash_password(password: str, salt: Optional[str] = None) -> tuple[str, str]:
    """
    返回 (hashed_b64, salt_b64)。salt 为 None 时随机生成。
    输出格式兼容存储，调用方负责组装最终字符串。
    """
    if salt is None:
        salt = base64.b64encode(os.urandom(16)).decode("ascii")
    dk = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("ascii"),
        iterations=_PBKDF2_ITERATIONS,
    )
    hashed = base64.b64encode(dk).decode("ascii")
    return hashed, salt


def verify_password(password: str, hashed_b64: str, salt_b64: str) -> bool:
    """常量时间比较，防止时序侧信道。"""
    dk = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt_b64.encode("ascii"),
        iterations=_PBKDF2_ITERATIONS,
    )
    return hmac.compare_digest(dk, base64.b64decode(hashed_b64))


# ═══════════════════════════════════════════════════════════════════════
# JWT 工具
# ═══════════════════════════════════════════════════════════════════════

def _jwt_secret() -> str:
    return config.JWT_SECRET_KEY or "fallback-insecure-secret-dev-only"


def generate_jwt(user_id: str, username: str) -> str:
    """生成 JWT（HS256，7 天过期）。"""
    now = time.time()
    payload: dict[str, Any] = {
        "user_id": user_id,
        "username": username,
        "iat": now,
        "exp": now + JWT_EXPIRE_SECONDS,
    }
    return jwt.encode(payload, _jwt_secret(), algorithm=JWT_ALGORITHM)


def decode_jwt(token: str) -> Optional[dict]:
    """
    解码并校验 JWT。成功返回 payload dict，失败抛 _JwtError（线程安全）。
    """
    try:
        payload = jwt.decode(token, _jwt_secret(), algorithms=[JWT_ALGORITHM])
        if not isinstance(payload, dict):
            raise _JwtError("JWT payload is not an object")
        if not payload.get("user_id") or not payload.get("username"):
            raise _JwtError("JWT missing required claims")
        return payload
    except jwt.ExpiredSignatureError as e:
        raise _JwtError("Token 已过期，请重新登录") from e
    except jwt.InvalidTokenError as e:
        raise _JwtError(f"Token 无效: {e}") from e
    except _JwtError:
        raise
    except Exception as e:
        raise _JwtError(f"Token 解析失败: {e}") from e


class _JwtError(Exception):
    """JWT 解码失败，携带面向用户的安全错误信息。"""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


# ═══════════════════════════════════════════════════════════════════════
# 用户 CRUD
# ═══════════════════════════════════════════════════════════════════════

def create_user(username: str, password: str) -> tuple[dict, Optional[str]]:
    """
    创建用户。成功返回 (user_record, None)，失败返回 (None, error_message)。
    用户名校验：2-64 字符，只允许字母、数字、下划线、连字符。
    密码校验：至少 8 字符。
    """
    import re as _re
    if not _re.match(r"^[a-zA-Z0-9_\-\u4e00-\u9fff]{2,64}$", username):
        return None, "用户名仅允许字母、数字、下划线、连字符或中文，长度 2-64 字符"
    if len(password) < 8:
        return None, "密码长度至少 8 个字符"

    user_id = str(uuid.uuid4())
    hashed, salt = hash_password(password)
    record: dict[str, Any] = {
        "user_id": user_id,
        "username": username,
        "password_hash": hashed,
        "password_salt": salt,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    path = os.path.join(USERS_DIR, f"{user_id}.json")
    # 检查用户名是否已存在（遍历 users 目录）
    if os.path.isdir(USERS_DIR):
        for filename in os.listdir(USERS_DIR):
            if not filename.endswith(".json"):
                continue
            existing = _read_json(os.path.join(USERS_DIR, filename))
            if existing and existing.get("username") == username:
                return None, f"用户名 '{username}' 已被注册"
    _write_json(path, record)
    return record, None


def find_user_by_username(username: str) -> Optional[dict]:
    """按用户名查找用户。"""
    if not os.path.isdir(USERS_DIR):
        return None
    for filename in os.listdir(USERS_DIR):
        if not filename.endswith(".json"):
            continue
        user = _read_json(os.path.join(USERS_DIR, filename))
        if user and user.get("username") == username:
            return user
    return None


def authenticate_user(username: str, password: str) -> Optional[dict]:
    """用户名密码校验，成功返回用户记录，失败返回 None。"""
    user = find_user_by_username(username)
    if not user:
        # 即使用户不存在也跑一次 hash，防止通过时序判断用户是否存在
        hash_password(password)
        return None
    if not verify_password(password, user["password_hash"], user["password_salt"]):
        return None
    return user


# ═══════════════════════════════════════════════════════════════════════
# Flask 认证中间件
# ═══════════════════════════════════════════════════════════════════════

def require_auth() -> None:
    """
    Flask before_request 中间件：校验 JWT，注入 g.auth_user。
    对 _PUBLIC_PATHS 中的路径直接放行。
    """
    path = request.path
    if path in _PUBLIC_PATHS:
        return

    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise _AuthError("请先登录。", 401)

    token = auth_header[len("Bearer "):].strip()
    try:
        payload = decode_jwt(token)
    except _JwtError as e:
        raise _AuthError(e.message, 401) from e
    if not payload:
        raise _AuthError("认证失败，请重新登录。", 401)

    g.auth_user = {
        "user_id": payload["user_id"],
        "username": payload["username"],
    }


class _AuthError(Exception):
    def __init__(self, message: str, status: int = 401):
        super().__init__(message)
        self.message = message
        self.status = status


def _handle_auth_error(e: _AuthError):
    """统一认证错误响应，带 WWW-Authenticate header。"""
    from flask import Response as _Response
    resp = _Response(
        json.dumps({"detail": e.message, "request_id": "auth:error"}, ensure_ascii=False),
        status=e.status,
        mimetype="application/json",
    )
    if e.status == 401:
        resp.headers["WWW-Authenticate"] = 'Bearer realm="resume-matcher"'
    return resp
"""
快速冒烟测试：验证多用户认证 + 数据隔离。
不启动真实服务器，直接用 Flask test client。
用法：python smoke_test_auth.py
"""
import json
import os
import sys
import tempfile

# 强制使用临时数据目录，避免污染真实数据（放在工作区内以满足沙箱写权限）
_TMP = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".smoke-tmp")
os.makedirs(_TMP, exist_ok=True)
os.environ["ENV"] = "local"

import config
config.DATA_DIR = _TMP
config.RESUMES_DIR = os.path.join(_TMP, "resumes")
config.JOBS_DIR = os.path.join(_TMP, "jobs")
config.LOG_DIR = os.path.join(_TMP, "logs")
os.makedirs(config.LOG_DIR, exist_ok=True)

# 需要重新加载模块（config 已初始化目录）
import importlib
for mod_name in ("store", "auth"):
    mod = importlib.import_module(mod_name)
    importlib.reload(mod)

from app import app

client = app.test_client()
passed = 0
failed = 0


def check(name: str, condition: bool, detail: str = ""):
    global passed, failed
    if condition:
        passed += 1
        print(f"  [PASS] {name}")
    else:
        failed += 1
        print(f"  [FAIL] {name} {detail}")


def post(path, data=None, token=None, headers=None):
    h = dict(headers or {})
    if data is not None:
        h["Content-Type"] = "application/json"
    if token:
        h["Authorization"] = f"Bearer {token}"
    return client.post(path, data=json.dumps(data) if data is not None else None, headers=h)


print("== 1. 免认证接口 ==")
r = client.get("/ping")
check("ping 免认证可访问", r.status_code == 200, f"status={r.status_code}")

print("== 2. 注册 ==")
r = post("/api/v1/auth/register", {"username": "alice", "password": "password123"})
check("alice 注册成功", r.status_code == 200, f"status={r.status_code} body={r.get_data(as_text=True)}")
alice_token = (r.get_json() or {}).get("data", {}).get("token", "")
check("alice 拿到 token", bool(alice_token))

r = post("/api/v1/auth/register", {"username": "alice", "password": "password123"})
check("重复注册被拒绝", r.status_code == 409)

r = post("/api/v1/auth/register", {"username": "bob", "password": "short"})
check("弱密码被拒绝", r.status_code == 409, f"status={r.status_code}")

print("== 3. 登录 ==")
r = post("/api/v1/auth/login", {"username": "alice", "password": "password123"})
check("alice 登录成功", r.status_code == 200, f"status={r.status_code}")
alice_token = (r.get_json() or {}).get("data", {}).get("token", "")

r = post("/api/v1/auth/login", {"username": "alice", "password": "wrongpass"})
check("错误密码被拒绝", r.status_code == 401)

print("== 4. 未带 token 访问被拒 ==")
r = client.get("/api/v1/resumes?resume_id=x")
check("无 token 访问 resumes 返回 401", r.status_code == 401, f"status={r.status_code}")

print("== 5. 伪造 token 被拒 ==")
r = client.get("/api/v1/resumes?resume_id=x", headers={"Authorization": "Bearer fake.token.here"})
check("伪造 token 返回 401", r.status_code == 401, f"status={r.status_code}")

print("== 6. alice 上传简历 + JD + 分析 ==")
import io
from test_helpers import build_anonymous_resume_docx
r = client.post(
    "/api/v1/resumes/upload",
    data={"file": (io.BytesIO(build_anonymous_resume_docx()), "alice-resume.docx")},
    content_type="multipart/form-data",
    headers={"Authorization": f"Bearer {alice_token}"},
)
check("alice 上传简历", r.status_code == 200, f"status={r.status_code} body={r.get_data(as_text=True)[:200]}")
alice_resume_id = (r.get_json() or {}).get("resume_id", "")

r = post(
    "/api/v1/jobs/upload",
    {"resume_id": alice_resume_id, "job_descriptions": ["资深后端工程师，5年以上经验，熟悉Python"]},
    token=alice_token,
)
check("alice 上传 JD", r.status_code == 200, f"status={r.status_code} body={r.get_data(as_text=True)[:200]}")
alice_job_id = (r.get_json() or {}).get("job_id", [None])[0]

print("== 7. bob 注册并尝试越权 ==")
r = post("/api/v1/auth/register", {"username": "bob", "password": "password456"})
bob_token = (r.get_json() or {}).get("data", {}).get("token", "")
check("bob 注册成功", bool(bob_token))

r = client.get(f"/api/v1/resumes?resume_id={alice_resume_id}", headers={"Authorization": f"Bearer {bob_token}"})
check("bob 读取 alice 简历被拒(404)", r.status_code == 404, f"status={r.status_code}")

r = post(
    "/api/v1/jobs/upload",
    {"resume_id": alice_resume_id, "job_descriptions": ["测试JD"]},
    token=bob_token,
)
check("bob 用 alice 的 resume_id 上传 JD 被拒", r.status_code == 400, f"status={r.status_code}")

r = post(
    "/api/v1/resumes/hr-analysis",
    {"resume_id": alice_resume_id, "job_id": alice_job_id},
    token=bob_token,
)
check("bob 分析 alice 的数据被拒(404)", r.status_code == 404, f"status={r.status_code}")

r = post(
    "/api/v1/resumes/hr-analysis",
    {"resume_id": alice_resume_id, "job_id": alice_job_id},
    token=alice_token,
)
# LLM 未配置时会返回 500/503/422 之一，但不该是 401/404（数据归属校验通过）
check(
    "alice 自己分析通过归属校验（无 Key 时走到 LLM 报错而非越权）",
    r.status_code not in (401, 404),
    f"status={r.status_code} body={r.get_data(as_text=True)[:200]}",
)

print("== 8. auth/me ==")
r = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {bob_token}"})
me = (r.get_json() or {}).get("data", {})
check("auth/me 返回 bob", me.get("username") == "bob", f"me={me}")

print(f"\n结果：{passed} 通过 / {failed} 失败")
# 清理临时目录
import shutil
shutil.rmtree(_TMP, ignore_errors=True)
sys.exit(1 if failed else 0)
